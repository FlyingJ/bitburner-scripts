/** @param {NS} ns */
export async function main(ns) {
	const n = 0;
	ns.tprint(`${n} -> ${n.toExponential()}`);
}