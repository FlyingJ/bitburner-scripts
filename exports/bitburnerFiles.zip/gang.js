/** @param {NS} ns */
export async function main(ns) {
	ns.gang.createGang('NiteSec');
}