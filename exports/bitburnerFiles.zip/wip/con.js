const HOSTS = [
	'CSEC',
	'avmnite-02h',
	'I.I.I.I',
	'.',
	'run4theh111z',
];

/** @param {NS} ns */
export async function main(ns) {
	let flags = ns.flags([
		['target', 'n00dles'],
	]);

	for (let host of HOSTS) {
		ns.singularity.connect(host);
		await ns.sleep(2000);
	}
}